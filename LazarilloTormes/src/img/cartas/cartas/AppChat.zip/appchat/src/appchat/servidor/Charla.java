package appchat.servidor;

import java.util.ArrayList;

/**
 *
 * Objeto que guarda toda la conversación y envia 
 * las actualizaciones a todos los hilos conectados
 */
public class Charla {
    private StringBuffer charla=new StringBuffer();
    private ArrayList<HiloDeCliente> lista=new ArrayList<HiloDeCliente>();
    public synchronized void addHilo(HiloDeCliente hilo){
        lista.add(hilo);
    }
    public synchronized void addTexto(String texto){
        charla.append(texto);
        for (int i=0;i<lista.size();i++){
            lista.get(i).enviarTexto(texto);
        }
        System.out.println(texto);
    }    
}
