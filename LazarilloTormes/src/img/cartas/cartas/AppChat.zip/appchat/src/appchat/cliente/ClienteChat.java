package appchat.cliente;

import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Clase con el main de un cliente del chat.
 * Establece la conexion y crea la ventana y la clase de control.
 * 
 */

public class ClienteChat{
    /** Direccion del Servidor */
    private String DIRSERVIDOR="localhost";
    
    /** Numero de puerto al que se conecta */
    private int PUERTO=5557;
    
    /** Socket con el servidor del chat */
    private Socket socket;

    /** Panel con la ventana del cliente */
    private VentanaCliente ventanaCliente;

    /**
     * Arranca el Cliente de chat.
     * 
     */
    public static void main(String[] args)
    {
        new ClienteChat();
    }

    /**
     * Crea la ventana, establece la conexi�n e instancia al controlador.
     */
    public ClienteChat(){
        System.out.println("CLIENTE EN MARCHA");
        try{
            ventanaCliente=new VentanaCliente();
           // SOL1: socket=new Socket(DIRSERVIDOR, PUERTO);//REALIZA LA CONEXION              
           socket=new Socket();
           socket.connect(new InetSocketAddress(DIRSERVIDOR, PUERTO));             
           ControlCliente control = new ControlCliente(socket, ventanaCliente);
        } catch (Exception e){e.printStackTrace();}
    }
}
