package appchat.servidor;

import java.net.ServerSocket;
import java.net.Socket;

/**
 * Servidor de chat.
 * Acepta conexiones de clientes, crea un hilo para atenderlos, y espera la
 * siguiente conexion.
 *
 */
public class ServidorChat{
    /** Numero de puerto al que usa el CHAT */
    private int PUERTO=5557;
    
    /** Objeto en el que se guaradara toda la conversacion */
    private Charla charla = new Charla();

    
     /**
     * Arranca el Servidor de chat.
     * 
     */
    public static void main(String[] args){
        new ServidorChat();
    }

    /**
     * Se mete en un bucle infinito para ateder clientes, lanzando un hilo
     * para cada uno de ellos.
     */
    public ServidorChat(){
        ServerSocket socketServidor;
        System.out.println("SERVIDOR EN MARCHA");
        try {
            socketServidor = new ServerSocket(PUERTO);
            while (true){
                Socket cliente=socketServidor.accept();
                Runnable nuevoCliente = new HiloDeCliente(charla, cliente);
                Thread hilo = new Thread(nuevoCliente);
                hilo.start();
            }
        } catch (Exception e){e.printStackTrace();}
    }        
}
